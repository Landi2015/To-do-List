import * as React from 'react';
import { Text, View, StyleSheet,TouchableOpacity } from 'react-native';

const TodoList = (props) => {

  return (
    <View style={styles.items}>
    <View style={styles.itemLeft}>
    <TouchableOpacity style={styles.square}></TouchableOpacity>
    <Text style={styles.itemText}> { props.text}</Text>
    </View>
    <View style={styles.circular}></View>
    
    </View>
  )
};

const styles = StyleSheet.create({
  items: {
    padding: 15,
    borderRadius:10,
    flexDirection:'row',
    justifyContent: 'space-between',
    backgroundColor: '#FFFF',
    alignItems:'center',
    marginBottom:20,

  },
  itemLeft: {
    flexDirection:'row',
    alignItems:'centre',
    flexWrap:'wrap',
  },

  square:{
    width:24,
    height:24,
    backgroundColor:'#3281a8',
    opacity:0.4,
    borderRadius:5,
    marginRight:15,
  },

  itemText:{
    maxWidth:"80%"
  },

 
});



export default TodoList

